#Notes:
#Make sure shinycounter.py and save.txt are in the same folder
#Run shinycounter.py and follow instructions.
#I personally put the SHINY COUNTER folder in my onedrive, so I can pick up where I left off if I switch computers super easily with-
#The load and save feature!

#Program by @hibaristan on twitter
#If you have any critiques (Which I'm sure there are many), please let me know. I'm still a beginner and would love to hear!
#I'm sure there are already 3,000,000 different versions people have made, but this is just a little project for me to practice and-
#learn programming.

import os

def save_to_file(save_file):
    file = open(save_file, 'w')
    file.write(counter_update)
    file.write(odds_update)
    file.write(pokemon_update)
    file.write(gen_update)
    file.close()

def read_name(save_file):
    file = open(save_file, 'r')
    save = file.readlines()
    for line in save:
        modified.append(line.strip())
        return save

#Values
systems = 1
modified = []
counter = 0
odds = 8192
pokemon = "off"
gen = 0
exit_program = "false"
error = "Please avoid decimals and characters other than numbers. Press enter to continue."


#Setup
os.system('cls')
print("Welcome to the pokemon shiny counter!")
print('To get started, input "ins" and then enter to get instructions. If you just want a counter, press enter. If you want to take away from the counter, type "d" and then enter.')

#Main loop
while exit_program == "false":
    #printing the counter
    print("Counter: {}" .format(counter))
    print("Odds: 1/{}" .format(odds))
    if pokemon != "off":
        print("Hunting: {}" .format (pokemon))
    if gen != 0:
        print("Hunting on: Generation {}" .format(gen))
    if systems != 1:
        print("Hunting with: {} systems" .format(systems))
    if counter == odds:
        print("Consider taking a break?")

    #Detecting if enter is pressed
    inp = input()
    inp = inp.strip().lower()
    
    if inp == "":
        counter = counter + systems
    elif inp == "d":
        counter = counter - systems
    
    if inp == "ins":
        print('Press enter to add another reset to the counter, and type d before pressing enter to remove a reset. Type "ins" for instructions. Type "settings" to edit your shiny odds, change settings, and change values. Type "EXIT" to end the program.')
        print('If you would like to load data from the save file, type "load". If you would like to overwrite the save file, type "save".')
        inp = input('Press enter to continue.')
    if inp == "load":
        file1 = read_name('save1.txt')
        file2 = read_name('save2.txt')
        file3 = read_name('save3.txt')
        os.system('cls')

        while True:
            print("<========== Which data would you like to load? ==========>")
            print('File 1) {}' .format(file1[2]))
            print('File 2) {}' .format(file2[2]))
            print('File 3) {}' .format(file3[2]))
            try:
                file_choice = int(input())
            except:
                print()
            if file_choice <= 3 and file_choice >= 1:
                break
            else:
                os.system('cls')
                print('Please input an interger between 1 and 3.')

        os.system('cls')

        if file_choice == 1:
            save = file1
        if file_choice == 2:
            save = file2
        if file_choice == 3:
            save = file3

        print("<========== You would like to load this data? ==========>")
        print("Reset counter: {}" .format(save[0]))
        print("Odds: {}" .format(save[1]))
        print("Pokemon: {}" .format(save[2]))
        print("Generation: {}" .format(save[3]))
        print("Systems: {}" .format(save[4])) 
        print("Y/N")
        inp = input()
        inp = inp.strip().lower()
        if inp == "y":
            counter = int(save[0])
            odds = (int(save[1]))
            pokemon = save[2].strip()
            gen = save[3]
            systems = int(save[4])
            os.system('cls')
            print("Data loaded. Press enter to continue.")
            input()
        else:
            os.system('cls')
            print("Data not loaded. Press enter to continue.")
            input()

    if inp == "save":
        file1 = read_name('save1.txt')
        file2 = read_name('save2.txt')
        file3 = read_name('save3.txt')
        os.system('cls')
        while True:
            print("<========== Which data would you like to overwrite? ==========>")
            print('File 1) {}' .format(file1[2]))
            print('File 2) {}' .format(file2[2]))
            print('File 3) {}' .format(file3[2]))
            try:
                file_choice = int(input())
            except:
                print()
            if file_choice <= 3 and file_choice >= 1:
                break
            else:
                print('Please input an interger between 1 and 3.')

        os.system('cls')

        if file_choice == 1:
            save = file1
        if file_choice == 2:
            save = file2
        if file_choice == 3:
            save = file3

        print("<========== Would you like to overwrite this data? ==========>")
        print("Reset counter: {}" .format(save[0]))
        print("Odds: {}" .format(save[1]))
        print("Pokemon: {}" .format(save[2]))
        print("Generation: {}" .format(save[3]))
        print("Systems: {}" .format(save[4]))
        print("Y/N")
        inp = input()
        inp = inp.strip().lower()
        if inp == "y":
            counter_update = str(counter) + '\n'
            odds_update = str(odds) + '\n'
            pokemon_update = str(pokemon) + '\n'
            gen_update = str(gen) + '\n'
            systems_update = str(systems) + '\n'

            if file_choice == 1:
                save_to_file('save1.txt')
            if file_choice == 2:
                save_to_file('save2.txt')
            if file_choice == 3:
                save_to_file('save3.txt')

            os.system('cls')
            print("Data saved. Press enter to continue.")
            input()
        else:
            os.system('cls')
            print("Data not saved. Press enter to continue.")
            input()
    if inp == "settings":
        while True:
            os.system('cls')
            print("<=====Settings Menu=====>")
            print('Enter "POKEMON" to enter which pokemon you are hunting.')
            print('Enter "GEN" to change the generation you are hunting on.')
            print('Enter "ODDS" to change the odds of the shiny you are hunting.')
            print('Enter "RESETS" to edit the amount of times you have reset.')
            print('Enter "SYSTEMS" to edit the amount of systems you are resetting with.')
            print('Enter "CLOSE" to exit the settings menu and return to the counter.')
            inp = input()
            inp = inp.strip().lower()
            if inp == "pokemon":
                os.system('cls')
                pokemon = input('Enter the name of the pokemon you are hunting, and enter "OFF" to turn off the pokemon display.')
                print("You are hunting {}." .format(pokemon))
            if inp == "gen":
                os.system('cls')
                try:
                    gen = int(input('Which generation are you hunting on? Enter "OFF" if you would like to turn off the generation display.'))
                except:
                    print(error)
            if inp == "odds":
                os.system('cls')
                try:
                    odds = int(input("Your odds of getting a shiny are 1 in ?"))
                except:
                    input(error)

            if inp == "resets":
                os.system('cls')
                try:
                    counter = int(input("How many resets have you done so far?"))
                except:
                    input(error)
            if inp == "systems":
                os.system('cls')
                try:
                    systems = int(input("How many systems are you resetting with?"))
                except:
                    input(error)
            if inp == "close":
                break


        os.system('cls')
    os.system('cls')
    if inp == "exit":
        exit_program = "true"