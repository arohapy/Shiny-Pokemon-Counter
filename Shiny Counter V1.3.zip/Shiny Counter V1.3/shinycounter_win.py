#Notes:
#Make sure shinycounter.py and save.txt are in the same folder
#Run shinycounter.py and follow instructions.
#I personally put the SHINY COUNTER folder in my onedrive, so I can pick up where I left off if I switch computers super easily with-
#The load and save feature!

#Program by @hibaristan on twitter
#If you have any critiques (Which I'm sure there are many), please let me know. I'm still a beginner and would love to hear!
#I'm sure there are already 3,000,000 different versions people have made, but this is just a little project for me to practice and-
#learn programming.

import os
import time

#Values
modified = []
counter = 0
odds = 8192
pokemon = "off"
gen = 0
exit_program = "false"
error = "Please avoid decimals and characters other than numbers."

#Setup
os.system('cls')
print("Welcome to the pokemon shiny counter!")
print('To get started, input "ins" and then enter to get instructions. If you just want a counter, press enter. If you want to take away from the counter, type "d" and then enter.')

#Main loop
while exit_program == "false":
    #printing the counter
    print("Counter: {}" .format(counter))
    print("Odds: 1/{}" .format(odds))
    if pokemon != "off":
        print("Hunting: {}" .format (pokemon))
    if gen != 0:
        print("Hunting on: Generation {}" .format(gen))
    if counter == odds:
        print("Consider taking a break?")

    #Detecting if enter is pressed
    inp = input()
    inp = inp.strip().lower()
    
    if inp == "":
        counter = counter + 1
    elif inp == "d":
        counter = counter - 1
    
    if inp == "ins":
        print('Press enter to add another reset to the counter, and type d before pressing enter to remove a reset. Type "ins" for instructions. Type "settings" to edit your shiny odds, change settings, and change values. Type "EXIT" to end the program.')
        print('If you would like to load data from the save file, type "load". If you would like to overwrite the save file, type "save".')
        inp = input('Press enter to continue.')
    if inp == "load":
        file = open('save.txt', 'r')
        save = file.readlines()
        for line in save:
            modified.append(line.strip())
        os.system('clear')
        print("<========== Would you like to load this data? ==========>")
        print("Reset counter: {}" .format(save[0]))
        print("Odds: {}" .format(save[1]))
        print("Pokemon: {}" .format(save[2]))
        print("Generation: {}" .format(save[3]))
        inp = input("Y/N")
        inp = inp.strip().lower()
        if inp == "y":
            counter = int(save[0])
            odds = (int(save[1]))
            pokemon = save[2]
            gen = save[3]
            os.system('clear')
            print("Data loaded. Press enter to continue.")
            input()
        else:
            os.system('clear')
            print("Data not loaded. Press enter to continue.")
            input()
    if inp == "save":
        file = open('save.txt', 'r')
        save = file.readlines()
        for line in save:
            modified.append(line.strip())
        os.system('cls')
        print("<========== Would you like to overwrite this data? ==========>")
        print("Reset counter: {}" .format(save[0]))
        print("Odds: {}" .format(save[1]))
        print("Pokemon: {}" .format(save[2]))
        print("Generation: {}" .format(save[3]))
        inp = input("Y/N")
        inp = inp.strip().lower()
        if inp == "y":
            counter_update = str(counter) + '\n'
            odds_update = str(odds) + '\n'
            pokemon_update = str(pokemon) + '\n'
            gen_update = str(gen) + '\n'

            file = open('save.txt', 'w')
            file.write(counter_update)
            file.write(odds_update)
            file.write(pokemon_update)
            file.write(gen_update)
            file.close()
            os.system('cls')
            print("Data saved. Press enter to continue.")
            input()
        else:
            os.system('cls')
            print("Data not saved. Press enter to continue.")
            input()
    while inp == "settings":
        os.system('cls')
        print("<=====Settings Menu=====>")
        print('Enter "POKEMON" to enter which pokemon you are hunting.')
        print('Enter "GEN" to change the generation you are hunting on.')
        print('Enter "ODDS" to change the odds of the shiny you are hunting.')
        print('Enter "RESETS" to edit the amount of times you have reset.')
        print('Enter "CLOSE" to exit the settings menu and return to the counter.')
        settings = input()
        settings = settings.strip().lower()
        if settings == "pokemon":
            os.system('cls')
            pokemon = input('Enter the name of the pokemon you are hunting, and enter "OFF" to turn off the pokemon display.')
            print("You are hunting {}." .format(pokemon))
        if settings == "gen":
            os.system('cls')
            gen = input('Which generation are you hunting on? Enter "OFF" if you would like to turn off the generation display.')
            
        if settings == "odds":
            os.system('cls')
            try:
                odds = int(input("Your odds of getting a shiny are 1 in ?"))
            except:
                inp = input("Please avoid using characters other than numbers. Press enter to go back to the counter.")
            break

        if settings == "resets":
            os.system('cls')
            try:
                counter = int(input("How many resets have you done so far?"))
            except:
                print(error)
        if settings == "close":
            break


        os.system('cls')
    os.system('cls')
    if inp == "exit":
        exit_program = "true"